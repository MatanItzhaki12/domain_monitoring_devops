before running terraform apply, run "terraform init"
and then run "terraform plan" - check the procedure
if all is correct - run "terraform apply"